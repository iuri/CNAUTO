

var __TEST_DATA__=
[

["010-0","US","Sigmasoft","Jerry",50,57,80,46,"2008-10-02","www.sigmawidgets.com"],
["010-1","BR","IBM","Charles",79,37,40,90,"2008-04-24","www.ibm.com"],
["010-2","BR","HP","Vincent",91,75,31,40,"2008-02-17","www.hp.com"],
["020-3","FR","Nokia","Edward",61,31,80,47,"2008-10-16","www.nokia.com"],
["020-4","BR","Ericsson","Patrick",82,70,33,38,"2008-04-21","www.ericsson.com"],
["020-5","US","BEA","Leopold",90,77,98,36,"2008-08-07","www.bea.com"],
["030-6","BR","Microsoft","Terence",64,47,84,41,"2008-10-04","www.microsoft.com"],
["030-7","US","Google","Brent",35,73,97,83,"2008-03-02","www.google.com"],
["030-8","US","Yahoo","Sammy",91,41,31,64,"2008-06-24","www.yahoo.com"],
["040-9","FR","Msn","Evan",66,76,43,63,"2008-04-04","www.msn.com"]

];

