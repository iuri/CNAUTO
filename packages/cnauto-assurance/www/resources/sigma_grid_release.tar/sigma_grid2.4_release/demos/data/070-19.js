{
	
data : [
["013","Glass",45,73,0.21,1,0.3,"Deliver Center","Other","Some notes"],
["013","Glass",45,40,0.24,0,0.1,"Deliver Center","UPS","What?"],
["005","Cameos",64.8,2,0.35,1,0.2,"Deliver Center","Fedex","Deliver to my home"],
["006","Citrine",104,94,0.11,0,0.2,"Branch","Other","Deliver to my home"],
["007","Coral",12,40,0.29,1,0.4,"Deliver Center","Other","What?"],
["012","Garnet",25.9,97,0.34,0,0.1,"Customer","UPS","What?"],
["005","Cameos",64.8,88,0.39,1,0.05,"Other","WestUnion","Deliver to my home"],
["012","Garnet",25.9,58,0.02,0,0.1,"Customer","Other","Some notes"],
["010","Emerald",26,24,0.31,1,0.05,"Deliver Center","Fedex","Some notes"],
["008","Crystal",6.84,38,0.05,1,0.05,"Customer","WestUnion","-"],
["016","Opal",2.3,38,0.36,0,0.2,"Customer","Fedex","Deliver to my home"],
["017","Pearl",27,7,0.17,1,0.3,"Customer","Fedex","Some notes"],
["004","Aquamarine",32.4,77,0.31,1,0.4,"Branch","Fedex","-"],
["008","Crystal",6.84,15,0.06,1,0.05,"Branch","Other","-"],
["015","Onyx",24.1,18,0.09,0,0.4,"Customer","UPS","-"],
["014","Moissanite",31,17,0.2,1,0.3,"Customer","UPS","What?"],
["016","Opal",2.3,66,0.09,1,0.2,"Branch","UPS","Deliver to my home"]
],
pageInfo : {totalRowNum:23},


exception:''

}