{
	
data : [
["010-0","MA","Jerry","Keith",50,57,80,46,"2008-10-02"],
["010-1","SP","Charles","Marks",79,37,40,90,"2008-04-24"],
["010-2","SP","Vincent","Harrison",91,75,31,40,"2008-02-17"],
["020-3","RA","Edward","Sidney",61,31,80,47,"2008-10-16"],
["020-4","CA","Patrick","Solomon",82,70,33,38,"2008-04-21"],
["020-5","MA","Leopold","Glendon",90,77,98,36,"2008-08-07"]


],
pageInfo : {totalRowNum:23},


exception:''

}

